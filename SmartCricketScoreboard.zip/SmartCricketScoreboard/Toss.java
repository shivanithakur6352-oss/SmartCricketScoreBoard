import java.util.Random;
import java.util.Scanner;

public class Toss {

    private Team battingTeam;
    private Team bowlingTeam;

    public void startToss(Team team1, Team team2) {

        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        System.out.println("\n========== TOSS ==========");

        System.out.println(team1.getTeamName() + " choose:");
        System.out.println("1. Heads");
        System.out.println("2. Tails");

        int choice = sc.nextInt();

        int tossResult = random.nextInt(2) + 1;

        String result = (tossResult == 1) ? "Heads" : "Tails";

        System.out.println("Coin Result : " + result);

        Team winner;

        if (choice == tossResult) {
            winner = team1;
        } else {
            winner = team2;
        }

        System.out.println("\nToss Winner : " + winner.getTeamName());

        System.out.println("Choose:");
        System.out.println("1. Bat");
        System.out.println("2. Bowl");

        int decision = sc.nextInt();

        if (decision == 1) {
            battingTeam = winner;
            bowlingTeam = (winner == team1) ? team2 : team1;
        } else {
            bowlingTeam = winner;
            battingTeam = (winner == team1) ? team2 : team1;
        }

        System.out.println("\nBatting Team : " + battingTeam.getTeamName());
        System.out.println("Bowling Team : " + bowlingTeam.getTeamName());
    }

    public Team getBattingTeam() {
        return battingTeam;
    }

    public Team getBowlingTeam() {
        return bowlingTeam;
    }
}