import java.util.Scanner;

public class InputValidator {

    private static final Scanner sc = new Scanner(System.in);

    // Read any integer safely
    public static int getInt(String message) {

        while (true) {
            try {
                System.out.print(message);
                return Integer.parseInt(sc.nextLine());

            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }
    }

    // Read non-negative runs
    public static int getRuns() {

        while (true) {

            int runs = getInt("Enter Runs : ");

            if (runs >= 0)
                return runs;

            System.out.println("Runs cannot be negative.");
        }
    }

    // Read menu choice
    public static int getMenuChoice(int min, int max) {

        while (true) {

            int choice = getInt("Enter Choice : ");

            if (choice >= min && choice <= max)
                return choice;

            System.out.println("Invalid Menu Choice.");
        }
    }

    // Read wickets
    public static int getWickets(int currentWickets) {

        while (true) {

            if (currentWickets >= 10) {
                System.out.println("All wickets have already fallen.");
                return currentWickets;
            }

            return currentWickets + 1;
        }
    }

    // Read over limit
    public static int getTotalOvers() {

        while (true) {

            int overs = getInt("Enter Total Overs : ");

            if (overs > 0)
                return overs;

            System.out.println("Overs must be greater than zero.");
        }
    }

    // Validate extra runs
    public static int getExtraRuns() {

        while (true) {

            int runs = getInt("Enter Extra Runs : ");

            if (runs >= 0)
                return runs;

            System.out.println("Extras cannot be negative.");
        }
    }
}