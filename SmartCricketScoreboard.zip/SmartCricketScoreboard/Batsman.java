public class Batsman extends Player {

    private int runs;
    private int balls;
    private int fours;
    private int sixes;
    private boolean out;

    public Batsman(String name, int jerseyNumber) {
        super(name, jerseyNumber);
        runs = 0;
        balls = 0;
        fours = 0;
        sixes = 0;
        out = false;
    }

    public void addRuns(int run) {
        runs += run;
        balls++;

        if (run == 4)
            fours++;

        if (run == 6)
            sixes++;
    }

    public double strikeRate() {
        if (balls == 0)
            return 0;

        return (runs * 100.0) / balls;
    }

    public void setOut(boolean out) {
        this.out = out;
    }

    public int getRuns() {
        return runs;
    }

    public int getBalls() {
        return balls;
    }

    public int getFours() {
        return fours;
    }

    public int getSixes() {
        return sixes;
    }

    @Override
    public void displayInfo() {
        System.out.println(getName() + " - " + runs + "(" + balls + ")");
    }
}