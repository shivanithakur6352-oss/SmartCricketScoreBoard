public class MatchSummary {

    public static void displaySummary(
            Match match,
            String winner,
            Batsman highestScorer,
            Bowler bestBowler,
            String playerOfMatch,
            int totalFours,
            int totalSixes,
            int extras) {

        System.out.println("\n======================================");
        System.out.println("          MATCH SUMMARY");
        System.out.println("======================================");

        System.out.println("Winner            : " + winner);

        System.out.println("Batting Team      : "
                + match.getBattingTeam().getTeamName());

        System.out.println("Bowling Team      : "
                + match.getBowlingTeam().getTeamName());

        System.out.println("Final Score       : "
                + match.getTotalRuns() + "/"
                + match.getWickets());

        System.out.println("Overs             : "
                + match.getOvers() + "."
                + match.getBalls());

        System.out.printf("Run Rate          : %.2f\n",
                match.currentRunRate());

        System.out.println("--------------------------------------");

        System.out.println("Highest Scorer");
        highestScorer.displayInfo();

        System.out.println();

        System.out.println("Best Bowler");
        bestBowler.displayInfo();

        System.out.println();

        System.out.println("Player of the Match : "
                + playerOfMatch);

        System.out.println();

        System.out.println("Total Fours : "
                + totalFours);

        System.out.println("Total Sixes : "
                + totalSixes);

        System.out.println("Extras : "
                + extras);

        System.out.println("======================================");
    }
}