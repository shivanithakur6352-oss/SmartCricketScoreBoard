public class Match {

    private Team battingTeam;
    private Team bowlingTeam;

    private int totalRuns;
    private int wickets;

    private int overs;
    private int balls;

    private int target;

    public Match(Team battingTeam, Team bowlingTeam) {
        this.battingTeam = battingTeam;
        this.bowlingTeam = bowlingTeam;

        totalRuns = 0;
        wickets = 0;
        overs = 0;
        balls = 0;
        target = 0;
    }

    // Add Runs
    public void addRuns(int runs) {
        totalRuns += runs;
        addBall();
    }

    // Add Wicket
    public void addWicket() {
        wickets++;
        addBall();
    }

    // Add Extras
    public void addExtra(int runs) {
        totalRuns += runs;
    }

    // Update Ball
    private void addBall() {

        balls++;

        if (balls == 6) {
            overs++;
            balls = 0;
        }
    }

    // Set Target
    public void setTarget(int target) {
        this.target = target;
    }

    // Get Current Run Rate
    public double currentRunRate() {

        double totalOvers = overs + (balls / 6.0);

        if (totalOvers == 0)
            return 0;

        return totalRuns / totalOvers;
    }

    // Get Required Run Rate
    public double requiredRunRate(int totalOversLimit) {

        if (target == 0)
            return 0;

        int runsNeeded = target - totalRuns;

        double oversLeft =
                totalOversLimit - (overs + (balls / 6.0));

        if (oversLeft <= 0)
            return 0;

        return runsNeeded / oversLeft;
    }

    public int getTotalRuns() {
        return totalRuns;
    }

    public int getWickets() {
        return wickets;
    }

    public int getOvers() {
        return overs;
    }

    public int getBalls() {
        return balls;
    }

    public int getTarget() {
        return target;
    }

    public Team getBattingTeam() {
        return battingTeam;
    }

    public Team getBowlingTeam() {
        return bowlingTeam;
    }
}