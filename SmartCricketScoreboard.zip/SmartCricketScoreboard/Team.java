import java.util.ArrayList;

public class Team {

    private String teamName;
    private ArrayList<Player> players;

    public Team(String teamName) {
        this.teamName = teamName;
        players = new ArrayList<>();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void displayPlayers() {

        System.out.println("\nPlayers of " + teamName);

        for (Player p : players) {
            p.displayInfo();
        }
    }

    public String getTeamName() {
        return teamName;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }
}
