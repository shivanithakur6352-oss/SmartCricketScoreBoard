public class Scoreboard {

    public static void displayScore(
            Match match,
            Batsman striker,
            Batsman nonStriker,
            Bowler bowler,
            String thisOver,
            int totalOvers) {

        System.out.println("\n========================================");
        System.out.println("      SMART CRICKET SCOREBOARD");
        System.out.println("========================================");

        System.out.println(match.getBattingTeam().getTeamName());

        System.out.println(match.getTotalRuns() + "/" + match.getWickets());

        System.out.println("Overs : "
                + match.getOvers() + "."
                + match.getBalls());

        System.out.printf("Current Run Rate : %.2f\n",
                match.currentRunRate());

        if (match.getTarget() > 0) {

            int runsNeeded =
                    match.getTarget() - match.getTotalRuns();

            int ballsBowled =
                    match.getOvers() * 6 + match.getBalls();

            int ballsLeft =
                    totalOvers * 6 - ballsBowled;

            System.out.println("Target : " + match.getTarget());

            if (runsNeeded > 0) {
                System.out.println("Need "
                        + runsNeeded
                        + " Runs in "
                        + ballsLeft
                        + " Balls");

                System.out.printf("Required Run Rate : %.2f\n",
                        match.requiredRunRate(totalOvers));
            } else {
                System.out.println("Target Achieved!");
            }
        }

        System.out.println("----------------------------------------");

        System.out.println("Striker");
        striker.displayInfo();

        System.out.println();

        System.out.println("Non-Striker");
        nonStriker.displayInfo();

        System.out.println();

        System.out.println("Bowler");
        bowler.displayInfo();

        System.out.println();

        System.out.println("This Over");

        System.out.println(thisOver);

        System.out.println("========================================");
    }
}