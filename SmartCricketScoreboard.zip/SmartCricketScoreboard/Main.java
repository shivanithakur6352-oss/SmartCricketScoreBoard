import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    static Team team1;
    static Team team2;

    static Toss toss;

    static Match match;

    static Batsman striker;
    static Batsman nonStriker;

    static Bowler currentBowler;

    static int totalOvers = 20;

    static int extras = 0;
    static int totalFours = 0;
    static int totalSixes = 0;

    static String thisOver = "";

    static String winner = "";
    static String playerOfMatch = "";

    public static void main(String[] args) {

        int choice;

        do {

            System.out.println("\n=================================");
            System.out.println(" SMART CRICKET SCOREBOARD ");
            System.out.println("=================================");

            System.out.println("1. Create Teams");
            System.out.println("2. Add Players");
            System.out.println("3. Toss");
            System.out.println("4. Start Match");
            System.out.println("5. Add Runs");
            System.out.println("6. Add Wicket");
            System.out.println("7. Add Extras");
            System.out.println("8. View Scoreboard");
            System.out.println("9. Match Summary");
            System.out.println("10. Save Match");
            System.out.println("11. Exit");

            choice = InputValidator.getMenuChoice(1,11);

            switch(choice){

                case 1:
                    createTeams();
                    break;

                case 2:
                    addPlayers();
                    break;

                case 3:
                    doToss();
                    break;

                case 4:
                    startMatch();
                    break;

                case 5:
                    addRuns();
                    break;

                case 6:
                    addWicket();
                    break;

                case 7:
                    addExtras();
                    break;

                case 8:
                    showScoreboard();
                    break;

                case 9:
                    showSummary();
                    break;

                case 10:
                    saveMatch();
                    break;

                case 11:
                    System.out.println("Thank You...");
                    break;
            }

        } while(choice != 11);

    }
    // Create Teams
public static void createTeams() {

    System.out.print("Enter Team 1 Name: ");
    String team1Name = sc.nextLine();

    System.out.print("Enter Team 2 Name: ");
    String team2Name = sc.nextLine();

    team1 = new Team(team1Name);
    team2 = new Team(team2Name);

    System.out.println("\nTeams created successfully!");
}
// Add Players
public static void addPlayers() {

    if (team1 == null || team2 == null) {
        System.out.println("Please create teams first.");
        return;
    }

    System.out.println("\nAdd Players for " + team1.getTeamName());

    for (int i = 1; i <= 11; i++) {

        System.out.print("Player " + i + " Name: ");
        String name = sc.nextLine();

        System.out.print("Jersey Number: ");
        int jersey = Integer.parseInt(sc.nextLine());

        team1.addPlayer(new Batsman(name, jersey));
    }

    System.out.println("\nAdd Players for " + team2.getTeamName());

    for (int i = 1; i <= 11; i++) {

        System.out.print("Player " + i + " Name: ");
        String name = sc.nextLine();

        System.out.print("Jersey Number: ");
        int jersey = Integer.parseInt(sc.nextLine());

        team2.addPlayer(new Batsman(name, jersey));
    }

    System.out.println("\nPlayers Added Successfully!");

    System.out.println("\n" + team1.getTeamName() + " Squad:");
    team1.displayPlayers();

    System.out.println("\n" + team2.getTeamName() + " Squad:");
    team2.displayPlayers();
}
// Perform Toss
public static void doToss() {

    if (team1 == null || team2 == null) {
        System.out.println("Please create teams first.");
        return;
    }

    toss = new Toss();
    toss.startToss(team1, team2);

    System.out.println("\nToss completed successfully.");
}
// Start Match
public static void startMatch() {

    if (toss == null) {
        System.out.println("Please complete the toss first.");
        return;
    }

    match = new Match(
            toss.getBattingTeam(),
            toss.getBowlingTeam());

    // Opening batsmen
    striker = (Batsman) match.getBattingTeam()
            .getPlayers()
            .get(0);

    nonStriker = (Batsman) match.getBattingTeam()
            .getPlayers()
            .get(1);

    // First bowler
    currentBowler = new Bowler("Bowler 1", 99);

    System.out.println("\n=================================");
    System.out.println("MATCH STARTED");
    System.out.println("=================================");

    System.out.println("Batting Team : "
            + match.getBattingTeam().getTeamName());

    System.out.println("Bowling Team : "
            + match.getBowlingTeam().getTeamName());

    System.out.println();

    System.out.println("Opening Batsmen:");
    striker.displayInfo();
    nonStriker.displayInfo();

    System.out.println();

    System.out.println("Current Bowler:");
    currentBowler.displayInfo();
}
// Add Runs
public static void addRuns() {

    if (match == null) {
        System.out.println("Start the match first.");
        return;
    }

    int runs = InputValidator.getRuns();

    match.addRuns(runs);
    striker.addRuns(runs);

    currentBowler.addBall(runs);

    if (runs == 4)
        totalFours++;

    if (runs == 6)
        totalSixes++;

    thisOver += runs + " ";

    // Change strike on odd runs
    if (runs % 2 == 1) {
        Batsman temp = striker;
        striker = nonStriker;
        nonStriker = temp;
    }

    // Change strike after every completed over
    if (match.getBalls() == 0) {
        Batsman temp = striker;
        striker = nonStriker;
        nonStriker = temp;
    }

    System.out.println("Runs Added Successfully.");
}
// Add Wicket
public static void addWicket() {

    if (match == null) {
        System.out.println("Start the match first.");
        return;
    }

    match.addWicket();

    striker.setOut(true);

    currentBowler.addWicket();

    thisOver += "W ";

    System.out.println(striker.getName() + " is OUT!");

    if (match.getWickets() >= 10) {
        System.out.println("All Out!");
        return;
    }

    int nextPlayerIndex = match.getWickets() + 1;

    striker = (Batsman) match.getBattingTeam()
            .getPlayers()
            .get(nextPlayerIndex);

    System.out.println("New Batsman : " + striker.getName());
}
// Add Extras
public static void addExtras() {

    if (match == null) {
        System.out.println("Start the match first.");
        return;
    }

    System.out.println("Extras");
    System.out.println("1. Wide");
    System.out.println("2. No Ball");
    System.out.println("3. Bye");
    System.out.println("4. Leg Bye");

    int choice = InputValidator.getMenuChoice(1, 4);

    int runs = InputValidator.getExtraRuns();

    extras += runs;

    match.addExtra(runs);

    switch (choice) {

        case 1:
            thisOver += "Wd ";
            break;

        case 2:
            thisOver += "Nb ";
            break;

        case 3:
            thisOver += "B ";
            break;

        case 4:
            thisOver += "Lb ";
            break;
    }

    System.out.println("Extra Added Successfully.");
}
// Show Live Scoreboard
public static void showScoreboard() {

    if (match == null) {
        System.out.println("Start the match first.");
        return;
    }

    Scoreboard.displayScore(
            match,
            striker,
            nonStriker,
            currentBowler,
            thisOver,
            totalOvers
    );
}
// Show Match Summary
public static void showSummary() {

    if (match == null) {
        System.out.println("Start the match first.");
        return;
    }

    // Decide winner (for now, based on target)
    if (match.getTarget() > 0 && match.getTotalRuns() >= match.getTarget()) {
        winner = match.getBattingTeam().getTeamName();
    } else {
        winner = "Match Completed";
    }

    // Simple Player of the Match
    playerOfMatch = striker.getName();

    MatchSummary.displaySummary(
            match,
            winner,
            striker,
            currentBowler,
            playerOfMatch,
            totalFours,
            totalSixes,
            extras
    );
}
// Save Match
public static void saveMatch() {

    if (match == null) {
        System.out.println("Start the match first.");
        return;
    }

    if (winner.isEmpty()) {
        winner = "Match Not Finished";
    }

    if (playerOfMatch.isEmpty()) {
        playerOfMatch = striker.getName();
    }

    FileManager.saveMatch(
            match,
            winner,
            playerOfMatch
    );
}
}