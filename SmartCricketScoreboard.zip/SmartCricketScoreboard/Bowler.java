public class Bowler extends Player {

    private double overs;
    private int runsGiven;
    private int wickets;

    public Bowler(String name, int jerseyNumber) {
        super(name, jerseyNumber);
    }

    public void addBall(int runs) {
        runsGiven += runs;
        overs += 0.1;

        if (overs - (int) overs >= 0.6) {
            overs = (int) overs + 1;
        }
    }

    public void addWicket() {
        wickets++;
    }

    public double economy() {

        double totalOvers = ((int) overs) + ((overs - (int) overs) / 0.6);

        if (totalOvers == 0)
            return 0;

        return runsGiven / totalOvers;
    }

    @Override
    public void displayInfo() {
        System.out.println(getName() + "  Overs:" + overs + " Wickets:" + wickets);
    }
}